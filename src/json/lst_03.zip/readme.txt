Drag both files into game directory
Launch game
You should hear a beep after a few seconds
Press F9 in-game to open the menu